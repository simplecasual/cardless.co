class RemoveColumnsFromUsers < ActiveRecord::Migration
  change_table :users do |t|
    t.remove :location, :title, :organization, :website, :avatar_file_name,
      :avatar_content_type, :avatar_file_size, :avatar_updated_at,
      :cover_file_name, :cover_content_type, :cover_file_size, :cover_updated_at
  end
end
