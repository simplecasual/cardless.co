class AddRelationshipTable < ActiveRecord::Migration
  def change
    create_table :cards_users do |t|
      t.integer :card_id
      t.integer :user_id
    end
  end
end
