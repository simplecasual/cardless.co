class DeviseTokenAuthCreateUsers < ActiveRecord::Migration
  def change
    change_table(:users) do |t|
      ## Required
      t.string :provider
      t.string :uid, null: false

      ## Tokens
      t.text :tokens
    end

    add_index :users, :uid
    add_index :users, :tokens
  end
end
