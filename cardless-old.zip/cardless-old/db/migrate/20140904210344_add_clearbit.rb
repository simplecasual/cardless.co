class AddClearbit < ActiveRecord::Migration
  def change
    add_column :cards, :clearbit, :text
  end
end
