class CreateCardTable < ActiveRecord::Migration
  def change
    create_table :cards do |t|
      t.string :location
      t.string :title
      t.string :organization
      t.string :email
      t.string :website
      t.attachment :avatar
      t.attachment :cover
      t.references :user

      t.timestamps
    end
  end
end
