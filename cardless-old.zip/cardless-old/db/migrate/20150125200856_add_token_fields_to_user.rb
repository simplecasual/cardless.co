class AddTokenFieldsToUser < ActiveRecord::Migration
  def change
    add_column :users, :access_token, :string, default: ""
    add_column :users, :refresh_token, :string, default: ""
  end
end
