class CreateMessages < ActiveRecord::Migration
  def change
    create_table :messages do |t|
      t.string :from, array: true, default: []
      t.string :to, array: true, default: []
      t.string :cc, array: true, default: []
      t.text :subject
      t.datetime :date
      t.belongs_to :user, null: false, index: true
    end
  end
end
