class DropCardsUsersTable < ActiveRecord::Migration
  def change
    drop_table :cards_users
  end
end
