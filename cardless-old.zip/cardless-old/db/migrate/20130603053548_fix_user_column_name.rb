class FixUserColumnName < ActiveRecord::Migration
  def change
    rename_column :users, :orginization, :organization
  end
end
