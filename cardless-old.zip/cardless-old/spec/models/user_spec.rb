require 'spec_helper'

describe User  do
  describe '#name' do
    it 'returns the users first and last name' do
      user = create(:user, first_name: 'Party', last_name: 'Guy')

      expect(user.name).to eq('Party Guy')
    end
  end
end
