require "spec_helper"

describe Message do
  pending
end
