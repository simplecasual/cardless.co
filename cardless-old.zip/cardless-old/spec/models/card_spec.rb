require 'spec_helper'

describe Card  do
end
