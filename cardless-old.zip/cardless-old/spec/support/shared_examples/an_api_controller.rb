shared_examples_for "an api controller" do |verb, method, params|
  it "restricts access without authentication" do
    if verb == "GET"
      get method, params
    elsif verb == "POST"
      post method, params
    elsif verb == "DELETE"
      delete method, params
    else
      patch method, params
    end

    expect(response.code).to eq "401"
  end
end
