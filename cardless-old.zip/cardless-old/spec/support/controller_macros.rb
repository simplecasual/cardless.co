module ControllerMacros
  def login_and_return_admin
    @request.env["devise.mapping"] = Devise.mappings[:admin]
    admin = FactoryGirl.create(:admin)
    auth_headers = admin.create_new_auth_token
    @request.headers.merge!(auth_headers)
    sign_in admin
    admin
  end

  def login_and_return_user
    user = FactoryGirl.create(:user)
    @request.env["devise.mapping"] = Devise.mappings[:user]
    auth_headers = user.create_new_auth_token
    @request.headers.merge!(auth_headers)
    sign_in user
    user
  end

# This is an example token hash, such fuck faces
# {"access-token"=>"54JWzj9ND5uejJgJ4BlJ8Q",
#  "token-type"=>"Bearer",
#  "client"=>"hYKKS6BrMJBxrolrqVmY5Q",
#  "expiry"=>"1427060244",
#  "uid"=>"1233"}
end
