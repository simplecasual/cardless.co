require 'rails_helper'

RSpec.describe WebhookController, :type => :controller do

end
