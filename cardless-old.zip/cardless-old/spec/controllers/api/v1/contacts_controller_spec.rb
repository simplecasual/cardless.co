require "spec_helper"

describe Api::V1::ContactsController, type: :controller do
  describe "#delete" do
    context "logged out" do
      it_behaves_like "an api controller", "DELETE", :destroy, id: 1
    end

    context "logged in" do
      context "error case" do
        it "returns the error json" do
          user = login_and_return_user
          contact = FactoryGirl.create(:contact, user: user)
          Contact.any_instance.stub(:destroy).and_return(false)
          params = { id: contact.id }

          delete :destroy, params

          expect(response.code).to eq "422"
        end
      end

      context "successful case" do
        it "returns the created contact json" do
          user = login_and_return_user
          contact = FactoryGirl.create(:contact, user: user)
          params = { id: contact.id }

          delete :destroy, params

          expect(response.code).to eq "200"
        end
      end
    end
  end

  describe "#create" do
    context "logged out" do
      it_behaves_like "an api controller", "POST", :create, {}
    end

    context "logged in" do
      context "error case" do
        it "returns the error json" do
          login_and_return_user
          params = { contact: { note: "a note" } }

          post :create, params

          expect(response.code).to eq "422"
        end
      end

      context "successful case" do
        it "returns the created contact json" do
          login_and_return_user
          params = { contact: { note: "a note", email: "rich@rines.com" } }

          post :create, params

          expect(response.code).to eq "200"
          expect(JSON.parse(response.body)["note"]).to eq "a note"
        end
      end
    end
  end

  describe "#update" do
    context "logged out" do
      it_behaves_like "an api controller", "PATCH", :update, id: 1
    end

    context "logged in" do
      context "error case" do
        it "returns the error json" do
          user = login_and_return_user
          contact = FactoryGirl.create(:contact, user: user)
          # too lazy to figure out why stubbing contact wont work
          Contact.any_instance.stub(:update_attributes).and_return(false)
          params = { id: contact.id, contact: { note: "title" } }

          patch :update, params

          expect(response.code).to eq "422"
        end
      end

      context "successful case" do
        it "returns the updated contact json" do
          user = login_and_return_user
          contact = FactoryGirl.create(:contact, note: "a note", user: user)
          params = { id: contact.id, contact: { note: "a better note" } }


          patch :update, params

          expect(response.code).to eq "200"
          expect(JSON.parse(response.body)["note"]).to eq "a better note"
        end
      end
    end
  end

  describe "#index" do
    context "logged out" do
      it_behaves_like "an api controller", "GET", :index, {}
    end

    context "logged in" do
      it "returns cards json" do
        user = login_and_return_user
        FactoryGirl.create_list(:card, 2, user_id: user.id)
        contacts = FactoryGirl.create_list(:contact, 2, user: user)

        get :index

        expect(response.code).to eq "200"
        # shitty test but IDGAF
        expect(JSON.parse(response.body)["my_cards"].count).to eq user.my_cards.count - 1 # the user's own card
        expect(JSON.parse(response.body)["contacts"].count).to eq user.contacts.count
      end
    end
  end

  describe "#show" do
    context "logged out" do
      it_behaves_like "an api controller", "GET", :show, id: 1
    end

    context "logged in" do
      it "returns card/contact json" do
        user = login_and_return_user
        contact = FactoryGirl.create(:contact, user: user)

        get :show, id: contact.id

        expect(response.code).to eq "200"
        expect(response.body).to eq contact.card.to_json
      end
    end
  end
end
