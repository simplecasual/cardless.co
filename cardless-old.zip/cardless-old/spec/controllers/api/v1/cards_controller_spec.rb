require "spec_helper"

describe Api::V1::CardsController, type: :controller do
  describe "#update" do
    context "logged out" do
      it_behaves_like "an api controller", "PATCH", :update, id: 1
    end

    context "logged in" do
      context "error case" do
        it "returns the error json" do
          login_and_return_user
          card = FactoryGirl.create(:card)
          # too lazy to figure out why stubbing card wont work
          Card.any_instance.stub(:update_attributes).and_return(false)
          params = { id: card.id, card: { title: "title" } }

          patch :update, params

          expect(response.code).to eq "422"
        end
      end

      context "successful case" do
        it "returns the updated card json" do
          login_and_return_user
          card = FactoryGirl.create(:card, title: "a title")
          params = { id: card.id, card: { title: "a better title" } }


          patch :update, params

          expect(response.code).to eq "200"
          expect(response.body).to eq card.reload.to_json
          expect(JSON.parse(response.body)["title"]).to eq "a better title"
        end
      end
    end
  end

  describe "#show" do
    context "logged out" do
      it_behaves_like "an api controller", "GET", :show, id: 1
    end

    context "logged in" do
      it "returns card json" do
        login_and_return_user
        card = FactoryGirl.create(:card)

        get :show, id: card.id

        expect(response.code).to eq "200"
        expect(response.body).to eq card.to_json
      end
    end
  end
end
