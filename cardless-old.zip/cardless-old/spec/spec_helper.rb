ENV["RAILS_ENV"] = "test"

require File.expand_path("../../config/environment", __FILE__)

require "rspec/rails"
require 'database_cleaner'
require "shoulda/matchers"

Dir[Rails.root.join("spec/support/**/*.rb")].each { |file| require file }

# module Features
#   # Extend this module in spec/support/features/*.rb
#   include Formulaic::Dsl
# end

RSpec.configure do |config|
  # config.include Features, type: :feature
  config.include Devise::TestHelpers, type: :controller
  config.include ControllerMacros, :type => :controller
  # include Warden::Test::Helpers
  # Warden.test_mode!
  config.include FactoryGirl::Syntax::Methods
  config.infer_base_class_for_anonymous_controllers = false
  config.infer_spec_type_from_file_location!
  config.use_transactional_fixtures = false
  # config.expect_with :rspec do |expectations|
  #   expectations.syntax = :expect
  # end

  # config.mock_with :rspec do |mocks|
  #   mocks.syntax = :expect
  # end

  config.order = :random

  config.before(:suite) do
    DatabaseCleaner.strategy = :transaction
    DatabaseCleaner.clean_with(:truncation)
  end

  config.around(:each) do |example|
    DatabaseCleaner.cleaning do
      example.run
    end
  end
end

ActiveRecord::Migration.maintain_test_schema!
Capybara.javascript_driver = :webkit
