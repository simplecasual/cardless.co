require 'spec_helper'

feature 'User updates name', js: true do
  scenario 'successfully' do
    user = create(:user, password: 'password')
    login_as(user)

    visit root_path
    find('a.edit-user').click

    within 'form#edit_user' do
      fill_in 'First name', with: 'Party'
      fill_in 'Last name', with: 'Guy'
      fill_in 'Current password', with: 'password'
      click_button 'Update'
    end

    page.should have_content('You updated your account successfully.')
  end
end

feature 'User changes password', js: true do
  scenario 'successfully' do
    user = create(:user, password: 'password')
    login_as(user)

    visit root_path
    find('a.edit-user').click

    within 'form#edit_user' do
      fill_in 'Current password', with: 'password'
      fill_in 'Password', with: 'newpassword'
      fill_in 'Password confirmation', with: 'newpassword'
      click_button 'Update'
    end

    click_link('Logout')

    fill_in 'Email', with: user.email
    fill_in 'Password', with: 'newpassword'
    click_button 'Sign in'

    page.should have_content(user.email)
  end
end

feature 'User changes password', js: true do
  scenario 'unsuccessfully' do
    user = create(:user, password: 'password')
    login_as(user)

    visit root_path
    find('a.edit-user').click

    within 'form#edit_user' do
      fill_in 'Current password', with: 'password'
      fill_in 'Password', with: 'newpassword'
      fill_in 'Password confirmation', with: 'wrongpassword'
      click_button 'Update'
    end

    page.should have_content("doesn't match confirmation")
  end
end
