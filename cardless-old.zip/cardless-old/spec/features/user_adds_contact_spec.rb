require 'spec_helper'

feature 'User adds contact', js: true do
  scenario 'email does not belong to existing user' do
    user = create(:user, password: 'password')
    login_as(user)

    visit root_path
    find('.new-contact').click

    within 'form#new_contact' do
      fill_in 'email', with: 'guy@party.com'
      fill_in 'contact_note', with: 'Some party guy.'
      click_button 'Add Contact'
    end

    page.should have_content('guy@party.com')
    page.should have_content('Some party guy.')
  end
end

feature 'User adds contact', js: true do
  scenario 'with same email as existing contact' do
    card = create(:card, email: 'guy@example.com')
    user = create(:user, password: 'password')
    contact = Contact.new
    contact.user = user
    contact.card = card
    contact.save!

    login_as(user)

    visit root_path
    click_link 'Add a Contact'
    find('.new-contact').click

    within 'form#new_contact' do
      fill_in 'email', with: 'guy@example.com'
      click_button 'Add Contact'
    end

    page.should have_content('guy@example.com is already in your contact list.')
  end
end
