require 'spec_helper'

feature 'User signs up', js: true do
  scenario 'successfully' do
    visit root_path
    click_link 'Sign up'

    fill_in 'First name', with: 'Guy'
    fill_in 'Last name', with: 'Smith'
    fill_in 'Email', with: 'user@example.com'
    fill_in 'Password', with: 'password', match: :prefer_exact
    fill_in 'Password confirmation', with: 'password'
    click_button 'Sign up'

    page.should have_content 'successfully'
  end
end

feature 'User signs up', js: true do
  scenario 'unsuccessfully' do
    visit root_path
    click_link 'Sign up'

    fill_in 'First name', with: 'Guy'
    fill_in 'Last name', with: 'Smith'
    fill_in 'Email', with: 'user@example.com'
    fill_in 'Password', with: '', match: :prefer_exact
    click_button 'Sign up'

    page.should have_content "can't be blank"
  end
end

feature 'User sings in' do
  scenario 'successfully' do
    user = create(:user, first_name: 'Party', last_name: 'Wolf', password: 'password')
    user.confirm!
    visit root_path

    fill_in 'Email', with: user.email
    fill_in 'Password', with: 'password'
    click_button 'Sign in'

    page.should have_content user.email
  end
end

feature 'User sings in' do
  scenario 'unsuccessfully' do
    user = create(:user, first_name: 'Party', last_name: 'Wolf', password: 'password')
    user.confirm!
    visit root_path

    fill_in 'Email', with: user.email
    fill_in 'Password', with: ''
    click_button 'Sign in'

    page.should have_content 'Invalid email or password.'
  end
end

feature 'User logs out' do
  scenario 'successfully' do
    user = create(:user)
    user.confirm!
    login_as(user)

    visit root_path
    visit edit_user_registration_path(user)
    click_link 'Logout'

    page.should have_content 'Sign in'
  end
end
