FactoryGirl.define do
  sequence(:email) { |n| "email#{n}@test.com" }
  sequence(:uid) { |n| "#{n}21838383838" }

  factory :user do
    first_name "John"
    last_name  "Doe"
    password "password"
    email
    uid
  end

  factory :card do
    email "card@example.com"
  end

  factory :contact do
    user
    card

    after(:build) { |contact| contact.class.skip_callback(:create, :after, :share_card_with_new_contact) }
  end
end
