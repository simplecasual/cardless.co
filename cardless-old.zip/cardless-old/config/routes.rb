require 'sidekiq/web'

Cardless::Application.routes.draw do
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'

  authenticate :user, lambda { |u| u.admin? } do
    mount Sidekiq::Web => '/sidekiq'
  end

  # TODO rip out omniauth
  # devise_for :users, :controllers => { omniauth_callbacks: "users/omniauth_callbacks", registrations: "registrations" } do
  #   authenticated :user do
  #     root :to => 'contacts#index'
  #   end
  # end
  #
  devise_for :users, controllers: { registrations: :registrations } do
    authenticated :user do
      root :to => 'contacts#index'
    end
  end

  root :to => 'welcome#index'

  resources :welcome, only: [:index]
  resources :users
  resources :cards, only: [:show, :edit, :update]
  resources :contacts

  post '/webhook/clearbit', to: 'webhook#clearbit'

  # API
  namespace :api do
    # changed this to a namespace instead of a scope should just affect the named helpers I believe
    namespace :v1 do
      mount_devise_token_auth_for 'User', at: 'auth'
      resources :cards, only: [:show, :update]
      resources :contacts, only: [:create, :update, :destroy, :show, :index]
      # TODO figure out if user stuff is handled by token auth
      # resources :users
    end
  end
end
