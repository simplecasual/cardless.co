# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cardless::Application.config.secret_key_base = 'dfdf81bdfa4ef896ca4cfb7e94a4b43c1b8875e6d6e3ce91c4ea57501edca7c41f1c30cedd0353f011ed21e32bf143b21a6e6819bd19e61bbeabb947e1b41fcd'
