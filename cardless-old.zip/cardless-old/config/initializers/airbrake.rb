Airbrake.configure do |config|
  config.api_key = '4b1f3e2ac11a7f73bd4de13d7fb81ae3'
end
