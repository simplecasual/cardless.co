## TODO
- Users api controller ish
- setup cors
  http://stackoverflow.com/questions/18538549/cant-get-rack-cors-working-in-rails-application
- What else?....need to noodle

## Curl for Keith
```
curl -v -H "Accept: application/json" -H "Content-type: application/json" -X
POST -d ' {
"first_name":"firstname","last_name":"lastname","email":"email@email.com","password":"app123ajkajha","password_confirmation":"app123ajkajha",
"confirm_success_url": "tetsststst.com/2829jsjs"}'
http://localhost:3000/api/v1/auth.json
```

left over from before
## Sending a test email
Contact.share('alexbaldwin@gmail.com', User.first).deliver
