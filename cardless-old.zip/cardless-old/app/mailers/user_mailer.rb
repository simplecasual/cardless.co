class UserMailer < ActionMailer::Base
  default from: "no-reply@cardlessapp.com"

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.contact.share.subject
  #

  def share_card(email, user, vcard)
    @user = user
    @card = user.my_cards.first

    attachments['contact.vcf'] = vcard.to_s
    
    mail(
      to: email,
      css: 'email',
      subject: "#{@user.name} has shared their contact information with you",
      from: "\"#{@user.name}\" <no-reply@cardlessapp.com>",
      reply_to: "\"#{@user.name}\" <#{@user.email}>",
    )
  end
end
