class WebhookController < ApplicationController
  skip_before_filter :authenticate_user!
  
  def clearbit
    if params[:type] == 'person' && 
        params[:status] == 200
      card = Card.where(email: params[:body][:email]).first
      
      if card
       card.clearbit = params[:body]
       card.save!
      end
    end

    head :ok
  end
end
