class ContactsController < ApplicationController
  def index
    @my_cards = current_user.my_cards
    @contacts = sorted_contacts.sort_by(&:created_at).reverse
  end

  def new
    @contact = Contact.new
  end

  def create
    contact = Contact.new(note: params[:contact][:note])
    card = Card.find_or_create_by(email: params[:email])

    contact.user = current_user
    contact.card = card

    if card.save && contact.save
      redirect_to contact
    else
      flash[:notice] = "#{params[:email]} is not valid or already in your contact list."
      redirect_to new_contact_path
    end
  end

  def edit
    @contact = Contact.find(params[:id])
  end

  def update
    @contact = Contact.find(params[:id])

    if @contact.update_attributes(params[:contact])
      flash[:success] = "Contact note updated."
      redirect_to @contact
    else
      render "edit"
    end
  end

  def destroy
    @contact = Contact.find(params[:id])
    @contact.destroy
    redirect_to(root_path)
  end

  def show
    @contact = Contact.find(params[:id])
    @card = @contact.card
  end

  private

  def sorted_contacts
    current_user.contacts.sort_by do |contact|
      unless contact.card.owner.nil?
        contact.card.owner.name
      else
        contact.card.email
      end
    end
  end
end
