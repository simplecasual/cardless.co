class Api::BaseController < ApplicationController
  include DeviseTokenAuth::Concerns::SetUserByToken
  # TODO we should probably restrict the cardless controllers that are currently
  # in existence but are unused, or just comment the routes out

  protect_from_forgery with: :null_session

  before_action :authenticate_user!
end
