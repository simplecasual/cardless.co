class Api::V1::ContactsController < Api::BaseController
  before_filter :authenticate_user!

  # README
  # I scoped all of these to current_user. I think that makes sense where in cards it does not - Rich

  def index
    # TODO sync with alex and keith on this and double check indexes
    # my cards includes the user's own card. we probably don't want this so I removed it from the array
    my_cards = current_user.my_cards
    @my_cards = my_cards.select { |card| card.email != current_user.email }
    @contacts = sorted_contacts.sort_by(&:created_at).reverse
    render json: { my_cards: @my_cards, contacts: @contacts }
  end

  def create
    contact = Contact.new(note: params[:contact][:note])
    card = Card.find_or_create_by(email: params[:contact][:email])

    contact.user = current_user
    contact.card = card

    if card.save && contact.save
      render json: contact
    else
      render json: {
        errors: {
          card: card.errors.full_messages,
          contact: contact.errors.full_messages
        }
      },
      status: 422
    end
  end

  def update
    @contact = current_user.contacts.find(params[:id])

    if @contact.update_attributes(params[:contact])
      render json: @contact
    else
      render json: { errors: @contact.errors.full_messages }, status: 422
    end
  end

  def destroy
    @contact = current_user.contacts.find(params[:id])
    if @contact.destroy
      render json: { success: true }
    else
      render json: { error: "Delete Failed Please try Again Keith :)" }, status: 422
    end
  end

  def show
    @contact = current_user.contacts.find(params[:id])
    @card = @contact.card
    render json: @card
  end

  private

  def sorted_contacts
    current_user.contacts.sort_by do |contact|
      unless contact.card.owner.nil?
        contact.card.owner.name
      else
        contact.card.email
      end
    end
  end
end
