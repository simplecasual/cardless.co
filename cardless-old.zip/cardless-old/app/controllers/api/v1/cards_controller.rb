class Api::V1::CardsController < Api::BaseController
  before_filter :authenticate_user!

  def show
    @card = Card.find(params[:id])
    render json: @card
  end

  def update
    @card = Card.find(params[:id])

    if @card.update_attributes(params[:card])
      render json: @card
    else
      render json: { errors: @card.errors.full_messages }, status: 422
    end
  end
end
