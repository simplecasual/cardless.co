require 'gmail_xoauth'
require 'mail'

class GmailContactsWorker
  include Sidekiq::Worker

  def perform(user_id)
    # this looks promising/ more friendly to work with
    # https://github.com/gmailgem/gmail
    user = User.find(user_id)
    options = {
      body: {
        client_id: ENV["GOOGLE_CLIENT_ID"],
        client_secret: ENV["GOOGLE_CLIENT_SECRET"],
        refresh_token: user.refresh_token,
        grant_type: "refresh_token"
      },
      headers: {
        'Content-Type' => 'application/x-www-form-urlencoded'

      }
    }
    refresh = HTTParty.post('https://accounts.google.com/o/oauth2/token', options)

    # any reason to save this token?
    token = refresh.parsed_response['access_token']

    imap = Net::IMAP.new('imap.gmail.com', 993, usessl = true, certs = nil, verify = false)
    imap.authenticate('XOAUTH2', user.email, token)
    imap.select('[Gmail]/Sent Mail') # [Gmail]/All Mail INBOX
    mail_ids = imap.search(['ALL'])

    mail_ids.each do |message_id|
      msg = imap.fetch(message_id,'RFC822')[0].attr['RFC822']
      mail = Mail.read_from_string msg
      Message.create!(cc: mail.cc, to: mail.to, from: mail.from, date: mail.date, subject: mail.subject, user: user)
    end

    # we need to do the card creating / associating and shit in here too
  end
end
