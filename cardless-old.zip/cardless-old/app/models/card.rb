class Card < ActiveRecord::Base
  belongs_to :owner, foreign_key: :user_id, class_name: 'User'
  has_many :contacts, dependent: :destroy
  has_many :users, through: :contacts

  serialize :clearbit, JSON

  attr_accessible :email, :location, :organization, :title,
    :website, :avatar, :cover, :user_id

  validates_format_of :email, :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i
  after_validation(on: :create) do
    fetch_clearbit
  end

  has_attached_file :avatar,
    default_url: '/assets/avatar/:style/missing.jpg',
    styles: {
      thumb: '100x100>',
      square: '200x200#',
      medium: '300x300>'
    }

  has_attached_file :cover,
    default_url: '/assets/cover/:style/missing.jpg',
    styles: {
      banner: '600x600',
      full: '1280x900'
    },
    convert_options: {
      full: '-blur 0x16 -fill black -colorize 20%'
    }

  validates_attachment :avatar,
      :content_type => { :content_type => ["image/jpeg", "image/gif", "image/png"]  }

  validates_attachment :cover,
      :content_type => { :content_type => ["image/jpeg", "image/gif", "image/png"]  }


  def clearbit
    super && Mash.new(super)
  end

  protected

  def fetch_clearbit
    if Rails.env.production?
      return unless email? && !(email =~ /@/).nil?
      self.clearbit ||= Clearbit::Person[email: email]
    end
  end
end
