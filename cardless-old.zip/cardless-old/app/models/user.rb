class User < ActiveRecord::Base
  has_many :my_cards, foreign_key: :user_id, class_name: 'Card'
  has_many :contacts, dependent: :destroy
  has_many :cards, through: :contacts

  devise :database_authenticatable, :registerable, :confirmable,
         :recoverable, :rememberable, :trackable, :validatable
  devise :omniauthable, :omniauth_providers => [:google_oauth2]
  include DeviseTokenAuth::Concerns::User

  attr_accessible :email, :first_name, :last_name,
    :password, :password_confirmation, :remember_me, :uid, :unconfirmed_email

  after_create :create_card

  def name
    "#{self.first_name} #{self.last_name}"
  end

  def self.find_for_google_oauth2(auth_hash)
    where(email: auth_hash.info.email).first_or_create do |user|
      user.password = Devise.friendly_token[0,20]
      user.first_name = auth_hash.info.first_name
      user.last_name = auth_hash.info.last_name
      # rip out confirmable? -> useful for invites
      user.confirmed_at = Time.now
      user.refresh_token = auth_hash.credentials.refresh_token
      user.access_token = auth_hash.credentials.token
      user.active = true
      # user.image = auth_hash.info.image
    end
  end

  private

  def create_card
    card = Card.find_or_create_by(email: self.email)
    card.owner = self
    card.save!
  end

  # def pull_gmail_messages_and_create_cards
  #   GmailContactsWorker.perform_async(id)
  # end
end
