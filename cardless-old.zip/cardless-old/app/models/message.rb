class Message < ActiveRecord::Base
  belongs_to :user

  attr_accessible :user, :date, :subject, :cc, :to, :from
end
