require 'vpim/vcard'

class Contact < ActiveRecord::Base
  belongs_to :user
  belongs_to :card

  validates :card_id, uniqueness: { scope: :user_id }

  attr_accessible :note

  after_create :share_card_with_new_contact

  private

  # TODO Rip this Out?
  def share_card_with_new_contact
    email = self.card.email

    UserMailer.share_card(email, self.user, generate_vcard).deliver
  end

  def generate_vcard
    # unless Rails.env.test?
    #   vcard = Vpim::Vcard::Maker.make2 do |maker|
    #     maker.add_name do |name|
    #       name.given = self.user.name
    #     end

    #     maker.add_email(self.card.email){ |e| e.location = 'work' }

    #     maker.add_photo do |photo|
    #       photo.link = self.card.avatar.url
    #     end

    #     maker.add_url(self.card.website)
    #   end
    #   vcard
    # end
  end
end
